#include "CwxAppHandler4TcpConn.h"
#include "CwxAppFramework.h"

CWINUX_BEGIN_NAMESPACE
CwxAppHandler4TcpConn::CwxAppHandler4TcpConn(CwxAppFramework* pApp,
                              CwxAppReactor *reactor)
                              :CwxAppHandler4Msg(pApp, reactor)
{
    m_next = NULL;
    m_unConnectPort = 0;
}

///��������
CwxAppHandler4TcpConn::~CwxAppHandler4TcpConn()
{
    if (getHandle() != CWX_INVALID_HANDLE)
    {
        ::close(getHandle());
        setHandle(CWX_INVALID_HANDLE);
    }
}

int CwxAppHandler4TcpConn::open (void * arg)
{
    if ((CwxAppConnInfo::ESTABLISHING == m_conn.getState())&&!getConnInfo().isActiveConn())
    {
        CwxSockStream stream(getHandle());
        stream.getRemoteAddr(m_remoteAddr);
    }
    return CwxAppHandler4Msg::open(arg);
}

///handle close
int CwxAppHandler4TcpConn::close(CWX_HANDLE )
{
    char szAddr[256];
    char szAddr1[256];
    CWX_UINT16 ucLocState = m_conn.getState();
    char const* szState;
    int iCloseReturn=0;

    if (getApp()->isStopped())
    {
        delete this;
        return 0;
    }

    switch(ucLocState)
    {
        case CwxAppConnInfo::IDLE:
            szState = "IDLE"; ///һ��û����reactorע��
            break;
        case CwxAppConnInfo::CONNECTING:
            szState = "CONNECTING";///������������ʱ����reactorע��
            CWX_ERROR(("Failure to connect to host:%s, port=%d, errno=%d",
                m_strConnectAddr.c_str(),
                m_unConnectPort,
                getConnErrNo()));
            if(isReg()) reactor()->removeHandler(this);
            break;
        case CwxAppConnInfo::TIMEOUT:
            szState = "TIMEOUT"; ///����ע����timeout
            if(isReg()) reactor()->cancelTimer(this);
            break;
        case CwxAppConnInfo::ESTABLISHING:
            szState = "ESTABLISHING";///����ע������Ϣ�շ�
            if (CWX_INVALID_HANDLE != getHandle())
                reactor()->removeHandler(this, false);
            break;
        case CwxAppConnInfo::ESTABLISHED:
            szState = "ESTABLISHED";///һ��ע������Ϣ�շ�
            if (CWX_INVALID_HANDLE != getHandle())
                reactor()->removeHandler(this, false);
            break;
        case CwxAppConnInfo::FAILED:
            szState = "FAILED";///һ��û��ע����Ϣ�շ�
            break;
        default:
            szState = "Unknown";
            CWX_ASSERT(0);
            break;
    }
    if (CWX_INVALID_HANDLE != getHandle())
    {
        CWX_DEBUG(("Connection closed. State = %s, Local_Ip=%s, Local_port=%d, Remote_Ip=%s, Remote_port=%d, Active-Close=%s", 
            szState,
            getLocalAddr(szAddr, 255),
            getLocalPort(),
            m_conn.isActiveConn()? this->getConnectAddr().c_str():getRemoteAddr(szAddr1, 255),
            m_conn.isActiveConn()? m_unConnectPort:getRemotePort(),
            m_conn.isActiveClose()?"yes":"no"));
    }

    m_conn.setState(CwxAppConnInfo::FAILED);

    //reconnection or close
    if (CwxAppConnInfo::ESTABLISHED == ucLocState)
    {
        if (m_conn.getParent()) this->m_conn.getParent()->removeConn(&m_conn);
        //re-dispatch all msg
        while(this->getNextMsg() == 1)
        {
            if (this->m_curSndingMsg && m_curSndingMsg->send_ctrl().isFailNotice())
            {
                getApp()->dipatchFailureSendMsg(m_curSndingMsg);
            }
            this->m_curSndingMsg = NULL;
        }
        iCloseReturn = this->getApp()->connClosed(*this);
        m_conn.setFailConnNum(1);
        //remove recieved data.
        if (this->m_recvMsgData) CwxMsgBlockAlloc::free(this->m_recvMsgData);
        this->m_recvMsgData = NULL;
    }
    else if (m_conn.isActiveConn())
    {
        m_conn.setFailConnNum(m_conn.getFailConnNum() + 1);
        iCloseReturn = this->getApp()->onFailConnect(*this);
    }

    if (getHandle () != CWX_INVALID_HANDLE)
    {
        ::close(getHandle());
        setHandle(CWX_INVALID_HANDLE);
    }
    if (m_conn.isNeedReconnect() && (iCloseReturn>=0))
    {
        CWX_UINT32 uiInternal = 0;
        if (m_conn.isReconn())
        {
            uiInternal = m_conn.getReconnDelay();
            m_conn.setReconn(false);
        }
        else
        {
            if (iCloseReturn > 0)
            {
                uiInternal = iCloseReturn;
            }
            else
            {
                uiInternal = 2 * m_conn.getMinRetryInternal() * getConnInfo().getFailConnNum();
                if (uiInternal > getConnInfo().getMaxRetryInternal()) uiInternal = getConnInfo().getMaxRetryInternal();
                uiInternal *= 1000;
            }
        }

        CWX_DEBUG(("Reconnect to address %s:%u after %d mili-second.", getConnectAddr().c_str(), getConnectPort(), uiInternal));
        if (uiInternal)
        {
            m_conn.setState(CwxAppConnInfo::TIMEOUT);
            if (this->reactor()->scheduleTimer(this, CwxTimeValue(uiInternal/1000, (uiInternal%1000) * 1000)) == -1)
            {
                CWX_ERROR(("Failure schedule_timer to noticeReconnect for conn id[%u]", m_conn.getConnId()));
                reactor()->removeHandlerByConnId(m_conn.getConnId());
                delete this;
                return 0;
            }
        }
        else
        {
            if (-1 == getApp()->getTcpConnector()->connect(this,
                m_strConnectAddr.c_str(),
                m_unConnectPort))
            {
                CWX_ERROR(("Failure to reconnect ip:%s, port=%u, errno=%d",
                    m_strConnectAddr.c_str(),
                    m_unConnectPort,
                    errno));
                this->close();
            }
        }
    }
    else
    {
        reactor()->removeFromConnMap(m_conn.getConnId());
        getApp()->getHandlerCache()->cacheTcpHandle(this);
    }

    return 0;
}

///��ʱ
void CwxAppHandler4TcpConn::handle_timeout()
{
    if (getApp()->isStopped()) return ;
    if (-1 == getApp()->getTcpConnector()->connect(this,
        m_strConnectAddr.c_str(),
        m_unConnectPort))
    {
        this->close();
    }
}


/**
@brief ��ȡ���ӵĶԶ˵�ַ��ֻ��STREAM_TYPE_TCP��STREAM_TYPE_UNIX��Ч
@param [in,out] szBuf ���ص�ַ��buf,��ȡ�ɹ�����\0������
@param [in] unSize szBuf�Ĵ�С��
@return ����szBuf
*/
char* CwxAppHandler4TcpConn::getRemoteAddr(char* szBuf, CWX_UINT16 unSize)
{
    if (getConnInfo().isActiveConn())
    {
        CwxCommon::copyStr(szBuf, unSize, m_strConnectAddr.c_str(), m_strConnectAddr.length());
    }
    else
    {
        szBuf[0] = 0x00;
        char szHostName[256];
        memset(szHostName, 0x00, 255);
        if (m_remoteAddr.getHostIp(szHostName, 255)){
            CwxCommon::copyStr(szBuf, unSize, szHostName, strlen(szHostName));
        }
        else
        {
            CWX_ERROR(("Failure to get remote addr"));
        }
    }
    return szBuf;
}
/**
@brief ��ȡ���ӵĶԶ�port��ֻ��STREAM_TYPE_TCP��Ч
@return ���ӶԶ˵�port
*/
CWX_UINT16 CwxAppHandler4TcpConn::getRemotePort()
{
    if (getConnInfo().isActiveConn()) return m_unConnectPort;
    return m_remoteAddr.getPort();
}
/**
@brief ��ȡ���ӱ��˵ĵ�ַ��ֻ��STREAM_TYPE_TCP��STREAM_TYPE_UNIX��Ч
@param [in,out] szBuf ���ص�ַ��buf,��ȡ�ɹ�����\0������
@param [in] unSize szBuf�Ĵ�С��
@return ����szBuf
*/
char* CwxAppHandler4TcpConn::getLocalAddr(char* szBuf, CWX_UINT16 unSize)
{
    if (CWX_INVALID_HANDLE == getHandle())
    {
        strcpy(szBuf, "invalid handle");
        return szBuf;
    }
    szBuf[0] = 0x00;
    char szHostName[256];
    memset(szHostName, 0x00, 256);
    CwxINetAddr addr;
    CwxSockStream stream(getHandle());
    if (-1 != stream.getLocalAddr(addr)){
        if (addr.getHostIp(szHostName, 255)){
            CwxCommon::copyStr(szBuf, unSize, szHostName, strlen(szHostName));
        }
    }
    else
    {
        CWX_ERROR(("Failure to get local addr, errno=%d", errno));
    }
    return szBuf;
}
/**
@brief ��ȡ���ӵı���port��ֻ��STREAM_TYPE_TCP��Ч
@return ���ӶԶ˵�port
*/
CWX_UINT16 CwxAppHandler4TcpConn::getLocalPort()
{
    if (CWX_INVALID_HANDLE == getHandle()) return 0;
    CwxINetAddr addr;
    CwxSockStream stream(getHandle());
    if (-1 != stream.getLocalAddr(addr)){
        return addr.getPort();
    }
    else
    {
        CWX_ERROR(("Failure to get local port, errno=%d", errno));
    }
    return 0;
}




CWINUX_END_NAMESPACE

