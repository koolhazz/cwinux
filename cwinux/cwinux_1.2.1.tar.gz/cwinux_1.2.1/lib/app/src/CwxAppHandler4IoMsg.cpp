#include "CwxAppHandler4IoMsg.h"
#include "CwxAppFramework.h"

CWINUX_BEGIN_NAMESPACE


CwxAppHandler4IoMsg::CwxAppHandler4IoMsg(CwxAppFramework* pApp, CwxAppReactor *reactor)
:CwxAppHandler4Msg(pApp, reactor)
{
    m_next = NULL;
}

///��������
CwxAppHandler4IoMsg::~CwxAppHandler4IoMsg()
{
}

///handle close
int CwxAppHandler4IoMsg::close(CWX_HANDLE )
{
    int iCloseReturn=0;
    CWX_UINT16 ucLocState = m_conn.getState();
    CWX_DEBUG(("Handler close, svr_id[%u], host_id[%u), conn_id[%u], handle[%d]",
        m_conn.getSvrId(),
        m_conn.getHostId(),
        m_conn.getConnId(),
        (int)getHandle()
        ));
    ///��reactor���Ƴ�
    if (CWX_INVALID_HANDLE != getHandle())
        reactor()->removeHandler(this);

    m_conn.setState(CwxAppConnInfo::FAILED);

    //reconnection or close
    if (CwxAppConnInfo::ESTABLISHED == ucLocState)
    {
        if (m_conn.getParent()) this->m_conn.getParent()->removeConn(&m_conn);
        //re-dispatch all msg
        while(this->getNextMsg() == 1)
        {
            if (m_curSndingMsg && m_curSndingMsg->send_ctrl().isFailNotice())
            {
                getApp()->dipatchFailureSendMsg(m_curSndingMsg);

            }
            this->m_curSndingMsg = NULL;
        }
        iCloseReturn = this->getApp()->connClosed(*this);
        //remove recieved data.
        if (this->m_recvMsgData) CwxMsgBlockAlloc::free(this->m_recvMsgData);
        this->m_recvMsgData = NULL;
    }
    if (getHandle () != CWX_INVALID_HANDLE)
    {
        ::close(getHandle());
        setHandle(CWX_INVALID_HANDLE);
    }
    getApp()->getHandlerCache()->cacheIoMsgHandle(this);
    return 0;
}


CWINUX_END_NAMESPACE

