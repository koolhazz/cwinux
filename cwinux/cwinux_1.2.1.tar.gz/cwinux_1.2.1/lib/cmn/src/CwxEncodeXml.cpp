#include "CwxEncodeXml.h"

CWINUX_BEGIN_NAMESPACE

map<string, string> const CwxEncodeXml::emptyXml;


CWINUX_END_NAMESPACE

