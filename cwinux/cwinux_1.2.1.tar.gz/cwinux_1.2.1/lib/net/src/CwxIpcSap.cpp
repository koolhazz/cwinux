#include "CwxIpcSap.h"
CWINUX_BEGIN_NAMESPACE
CwxIpcSap::CwxIpcSap(void)
{
    handle_=CWX_INVALID_HANDLE;
}
CwxIpcSap::~CwxIpcSap(void)
{
}

CWINUX_END_NAMESPACE
