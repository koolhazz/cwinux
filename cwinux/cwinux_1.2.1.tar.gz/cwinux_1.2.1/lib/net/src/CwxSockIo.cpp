#include "CwxSockIo.h"
CWINUX_BEGIN_NAMESPACE

/// Constructor.
CwxSockIo::CwxSockIo (void)
{

}

/// Destructor.
CwxSockIo::~CwxSockIo (void)
{

}



CWINUX_END_NAMESPACE
