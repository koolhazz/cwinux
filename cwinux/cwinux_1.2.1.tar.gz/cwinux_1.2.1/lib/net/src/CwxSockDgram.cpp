#include "CwxSockDgram.h"

CWINUX_BEGIN_NAMESPACE

CwxSockDgram::CwxSockDgram()
{

}

CwxSockDgram::CwxSockDgram(CWX_HANDLE handle)
{
    setHandle(handle);
}

CwxSockDgram::~CwxSockDgram(void)
{

}

CWINUX_END_NAMESPACE
