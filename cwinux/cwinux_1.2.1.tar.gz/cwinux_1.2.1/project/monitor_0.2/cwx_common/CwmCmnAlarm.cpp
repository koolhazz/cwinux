#include "CwmCmnAlarm.h"

string CwmCmnAlarm::m_arrAlarms[]={
    "clear",
    "warning",
    "minor",
    "major",
    "critical",
    "fatal"
};
