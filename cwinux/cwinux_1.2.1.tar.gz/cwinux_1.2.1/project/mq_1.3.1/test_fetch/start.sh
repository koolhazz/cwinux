./cwx_dispatch_test>/dev/null
cd test1
./cwx_dispatch_test>/dev/null
cd ../

