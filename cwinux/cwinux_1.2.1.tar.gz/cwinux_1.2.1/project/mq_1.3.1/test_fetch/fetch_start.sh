./cwx_mq_fetch >/dev/null

