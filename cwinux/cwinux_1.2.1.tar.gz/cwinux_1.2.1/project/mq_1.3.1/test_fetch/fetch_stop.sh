./cwx_mq_fetch -stop

