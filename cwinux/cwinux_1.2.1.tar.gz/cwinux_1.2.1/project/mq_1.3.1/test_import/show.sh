head -15 log/cwx_mq_import_01.log
tail log/cwx_mq_import_01.log
rm -f log/cwx_mq_import_01.log
