cd slave
./cwx_dispatch -stop
cd ..
./cwx_dispatch -stop

rm  /data1/dispatch_data/data/binlog/*
rm  /data3/dispatch_data/data/binlog/*

