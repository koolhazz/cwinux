./cwx_dispatch>/dev/null
cd slave
./cwx_dispatch>/dev/null
cd ../

