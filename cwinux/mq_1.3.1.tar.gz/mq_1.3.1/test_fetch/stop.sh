./cwx_dispatch_test -stop
cd test1
./cwx_dispatch_test -stop
cd ../

