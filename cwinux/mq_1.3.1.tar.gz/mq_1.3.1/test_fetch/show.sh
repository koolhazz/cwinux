head -15 log/cwx_dispatch_test_01.log
tail log/cwx_dispatch_test_01.log
rm -f log/cwx_dispatch_test_01.log
head -15 test1/log/cwx_dispatch_test_01.log
tail test1/log/cwx_dispatch_test_01.log
rm -f test1/log/cwx_dispatch_test_01.log
