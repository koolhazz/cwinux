./cwx_mq_import  >/dev/null

