./cwx_mq_import -stop

