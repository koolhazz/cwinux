ls -l  /data1/dispatch_data/data/binlog/*
ls -l  /data3/dispatch_data/data/binlog/*

